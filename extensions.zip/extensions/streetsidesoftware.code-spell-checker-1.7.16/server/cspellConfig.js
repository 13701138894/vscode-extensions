"use strict";
// Export the cspell settings to the client.
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=cspellConfig.js.map