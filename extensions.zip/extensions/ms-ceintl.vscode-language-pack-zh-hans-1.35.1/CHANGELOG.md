# Change Log
All notable changes to the "vscode-language-pack-zh-hans" language pack will be documented in this file.

## [Released]
* June 6, 2019 - Release for VS Code 1.35
* May 15, 2019 - Release for VS Code 1.34
* April 3, 2019 - Release for VS Code 1.33
* March 6, 2019 - Release for VS Code 1.32
* February 6, 2019 - Release for VS Code 1.31
* December 12, 2018 - Release for VS Code 1.30
* November 7, 2018 - Release for VS Code 1.29
* October 3, 2018 - Release for VS Code 1.28
* September 5, 2018 - Release for VS Code 1.27
* August 8, 2018 - Release for VS Code 1.26
* July 5, 2018 - Release for VS Code 1.25
* June 6, 2018 - Release for VS Code 1.24
* May 5, 2018 - Release for VS Code 1.23
* April 16, 2018 - Initial release
