# Change Log
### [1.2.0]
added context menu option to tab bar

### [1.1.1]
add `opera` support

change icon;  beautiful, right?

change Licence
### [1.0.0]
add `default browser` configuration option

add `open in other browsers`

### [0.0.3]
add `open file by right click menu item`

fix some bug

### [0.0.2]
add shortcut `Alt + B` 

modify the command on linux...

### [0.0.1]

BASIC SUPPORT...
