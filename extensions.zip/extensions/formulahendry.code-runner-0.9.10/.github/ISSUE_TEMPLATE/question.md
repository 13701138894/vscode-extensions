---
name: Question
about: Ask a question about Code Runner

---

<!-- Please search existing issues to avoid creating duplicates. -->
<!-- FYI issues: https://github.com/formulahendry/vscode-code-runner/issues?utf8=%E2%9C%93&q=is%3Aissue+label%3Afyi -->
