---
name: Feature request
about: Suggest an idea for this project

---

<!-- Please search existing issues to avoid creating duplicates. -->
<!-- FYI issues: https://github.com/formulahendry/vscode-code-runner/issues?utf8=%E2%9C%93&q=is%3Aissue+label%3Afyi -->

**Is your feature request related to a problem? Please describe.**
Description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
Description of what you want to happen.
