#### Thank you for creating an issue, please note that this project is being succeeded by https://github.com/CoenraadS/Bracket-Pair-Colorizer-2

#### If the issue still occurs in v2, please file an issue in the new repository.

